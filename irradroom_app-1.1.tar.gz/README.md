Uvnitř root složky tohoto repozitáře

```
tar -czvf ../flight-1.2.tar.gz *
```
